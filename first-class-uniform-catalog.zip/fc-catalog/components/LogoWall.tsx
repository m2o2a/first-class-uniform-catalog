"use client";

import Image from "next/image";
import { useLang } from "@/lib/lang-context";
import { sectors } from "@/lib/sectors";

export default function LogoWall() {
  const { t, lang } = useLang();

  return (
    <div className="space-y-14">
      {sectors.map((sector) => (
        <div key={sector.key}>
          <div className="flex items-baseline justify-between mb-5 border-b border-line pb-3">
            <h3 className="font-display font-bold text-lg text-ink">
              {t.sectorNames[sector.key]}
            </h3>
            <span className="text-xs text-steel tracking-widest2 font-semibold">
              {sector.logoCount} {lang === "ar" ? "عميل" : "clients"}
            </span>
          </div>
          <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-3">
            {Array.from({ length: sector.logoCount }).map((_, i) => (
              <div
                key={i}
                className="aspect-square rounded-lg border border-line bg-white p-2.5 flex items-center justify-center hover:border-royal hover:shadow-sm transition-all"
              >
                <div className="relative w-full h-full">
                  <Image
                    src={`/clients/logos/${sector.key}-${i + 1}.jpg`}
                    alt={`${t.sectorNames[sector.key]} client ${i + 1}`}
                    fill
                    sizes="(max-width: 768px) 33vw, 16vw"
                    className="object-contain"
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}
