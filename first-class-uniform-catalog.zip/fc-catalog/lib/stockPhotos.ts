// Free-to-use, commercial-license stock photography (Unsplash License — free for
// commercial use, no attribution legally required). Sourced individually and verified,
// NOT scraped indiscriminately. These are starter/placeholder images until real product
// photography is available — see README for how to replace them.
//
// To add more: find a photo on unsplash.com, open it, copy the "images.unsplash.com/photo-..."
// URL from the page (right-click the image → Copy Image Address), and add it below.

export const stockPhotos: Record<string, string[]> = {
  security: [
    "https://images.unsplash.com/photo-1772743227731-e16af7c8d85a?w=1200&q=80&auto=format&fit=crop"
  ],
  chef: [
    "https://images.unsplash.com/photo-1600565193348-f74bd3c7ccdf?w=1200&q=80&auto=format&fit=crop"
  ],
  construction: [
    "https://images.unsplash.com/photo-1758876734777-dcc6981f3671?w=1200&q=80&auto=format&fit=crop"
  ]
};
