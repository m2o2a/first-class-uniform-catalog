// Free-to-use, commercial-license stock video (Pexels License — free for commercial
// use, no attribution required). These are real garment-factory clips, individually
// sourced and verified — not AI-generated (Claude has no video-generation tool
// available). One is picked at random on each page load for the hero background.
//
// To add more: find a clip on pexels.com/videos, open it, right-click the video →
// Copy Video Address (or use the "Edit in Canva" link's file-url parameter), and
// add the direct videos.pexels.com/... URL below.

export const heroVideos: string[] = [
  "https://videos.pexels.com/video-files/15459704/15459704-uhd_2560_1440_24fps.mp4",
  "https://videos.pexels.com/video-files/15459705/15459705-uhd_2560_1440_24fps.mp4",
  "https://videos.pexels.com/video-files/15459706/15459706-uhd_2560_1440_24fps.mp4"
];
