export type Sector = {
  key: "security" | "hospitals" | "restaurants" | "cleaning" | "petroleum" | "construction" | "factories";
  count: string;
  logoCount: number;
};

// logoCount matches the exact number of individually-cropped logo files
// in public/clients/logos/{key}-{1..logoCount}.jpg
export const sectors: Sector[] = [
  { key: "security", count: "48", logoCount: 48 },
  { key: "hospitals", count: "8", logoCount: 8 },
  { key: "restaurants", count: "16", logoCount: 16 },
  { key: "cleaning", count: "16", logoCount: 16 },
  { key: "petroleum", count: "8", logoCount: 8 },
  { key: "construction", count: "24", logoCount: 24 },
  { key: "factories", count: "8", logoCount: 8 }
];
